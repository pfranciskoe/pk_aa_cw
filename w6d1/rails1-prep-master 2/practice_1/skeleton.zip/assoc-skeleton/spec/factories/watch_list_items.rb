FactoryGirl.define do
  factory :watch_list_item do
    
  end
end
